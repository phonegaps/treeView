import './TreeView.css';
import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleRight, faAngleDown } from "@fortawesome/free-solid-svg-icons";

const TreeView = ({ data, newKeyNames, getTreeViewCheckedData }) => {
    const [treeViewData, setTreeViewData] = useState();
    const [toggleItem, setToggleItem] = useState({});
    const [checkedValue, setCheckedValue] = useState([]);

    useEffect(() => {

        //Rename key
        if (Object.keys(newKeyNames).length > 0) {
            const renameKeys = (data, newKeyNames) => {
                const renameObjectKeys = (obj, keyMap) => {
                    const renamedObject = {};
                    for (const key in obj) {
                        if (keyMap.hasOwnProperty(key)) {
                            renamedObject[keyMap[key]] = obj[key];
                        } else {
                            renamedObject[key] = obj[key];
                        }
                    }
                    return renamedObject;
                }

                const renameKeysRecursively = (node, keyMap) => {
                    const renamedNode = renameObjectKeys(node, keyMap);
                    if (node.children) {
                        renamedNode.children = node.children.map(child => renameKeysRecursively(child, keyMap));
                    }
                    return renamedNode;
                }

                return data?.map(node => renameKeysRecursively(node, newKeyNames));
            }
            setTreeViewData(renameKeys(data, newKeyNames));
            // Rename key end

        } else {

            // add isChecked 
            const addKeyValueToObjects = (data, newKey, newValue) => {
                return data?.map(item => {
                    const newItem = { ...item };
                    newItem[newKey] = newValue;

                    if (newItem.children && newItem.children.length > 0) {
                        newItem.children = addKeyValueToObjects(newItem.children, newKey, newValue);
                    }

                    return newItem;
                });
            }
            setTreeViewData(addKeyValueToObjects(data, 'isChecked', false));
        }

    }, [data, newKeyNames]);

    // Child Checkbox toggle
    const toggleSubItem = (value) => {
        setToggleItem({ ...toggleItem, [value]: !toggleItem[value] });
    };

    // Change Handler
    const onChangeHandler = (e, value) => {
        setTreeViewData(checkboxHandler(treeViewData, e, value));
        getTreeViewCheckedData(checkedValue);
    };

    // CheckBox Handler
    const checkboxHandler = (data, e, value) => {
        return data?.map(item => {
            const updateItem = { ...item };

            if (updateItem.value === value) {
                updateItem.isChecked = e.target.checked;

                if (updateItem.isChecked === false) {
                    let checkedItemAll = e.target.id;
                    const checkItemSplit = checkedItemAll.split(' ');
                    checkItemSplit.shift()
                    parentUnChecked(treeViewData, checkItemSplit)
                }

                //checkedValue store or remove
                if (updateItem.isChecked === true || updateItem?.children?.length === 0) {

                    const checkedData = [...checkedValue];
                    checkedData.push(updateItem.value);
                    setCheckedValue(checkedData);
                } else if (updateItem.isChecked === false) {
                    const checkedData = [...checkedValue];
                    const index = checkedData.indexOf(value);
                    if (index > -1) {
                        checkedData.splice(index, 1);
                    }
                    setCheckedValue(checkedData);
                }

                if (updateItem.children && updateItem.children.length > 0) {
                    updateItem.children = childCheckboxHandler(updateItem.children, e)
                }
            }
            else if (updateItem.children && updateItem.children.length > 0) {
                updateItem.children = checkboxHandler(updateItem.children, e, value);
            }

            return updateItem;
        });
    };

    const childCheckboxHandler = (childData, e) => {

        return childData.map(childItem => {
            const updateChildItem = { ...childItem }
            updateChildItem.isChecked = e.target.checked;

            if (updateChildItem.children && updateChildItem.children.length > 0) {
                updateChildItem.children = childCheckboxHandler(updateChildItem.children, e)
            }

            return updateChildItem;
        })
    }

    const parentUnChecked = (data, unCheckedItems) => {
        const updateData = (items) => {
            return items.map(item => {
                const updateItem = { ...item };

                if (updateItem.children && updateItem.children.length > 0) {
                    updateItem.children = updateData(updateItem.children);
                    updateItem.isChecked = updateItem.children.every(child => child.isChecked);
                }

                if (unCheckedItems.includes(updateItem.value)) {
                    updateItem.isChecked = false;
                }

                return updateItem;
            });
        };

        const updatedData = updateData(data);
        const updatedParentData = updatedData.map(item => {
            const parentItem = { ...item };
            if (parentItem.children && parentItem.children.length > 0) {
                parentItem.isChecked = parentItem.children.every(child => child.isChecked);
            }
            return parentItem;
        });

        setTimeout(() => {
            setTreeViewData(updatedParentData);
        }, 500);
    };

    const renderTree = (items, itemValue, labelClass, depth = 0, checkedParent) => {

        let parentValues = checkedParent;
        return (
            <ul className='treeViewUl' style={{ marginLeft: (itemValue && `${depth === 1 ? 50 : 25}px`) }} idas={itemValue}>
                {items?.map((item, index) => (
                    <li key={item.value + index} className={`treeViewLi ${item.isChecked && 'treeViewLiSelectBG'} ${itemValue && 'treeViewLiSelectBorderLeft'}`} >
                        <span className="treeViewItem" style={{ marginLeft: itemValue && `-${25 + depth * 26}px` }}>

                            {item.children ? (
                                <FontAwesomeIcon
                                    onClick={() => toggleSubItem(item.value, item.children)}
                                    className="treeViewIcon"
                                    icon={toggleItem[item.value] ? faAngleDown : faAngleRight} />
                            ) : (<span className="treeViewEmptySpace"></span>)}

                            <input
                                type="checkbox"
                                name={item.value}
                                value={item.value}
                                checked={item.isChecked}
                                onChange={(e) => onChangeHandler(e, item.value)}
                                className="treeViewCheckbox" id={parentValues + ' ' + item.value} />

                            <label className={`treeViewLabel ${labelClass}`}
                                onClick={() => toggleSubItem(item.value, item.children)}
                                style={{ marginLeft: itemValue && `${depth * 26}px` }}>
                                {item.label}</label>

                        </span>
                        {item.children && toggleItem[item.value] && renderTree(item.children, item.value, 'treeViewLabelChild', depth + 1, (parentValues + ' ' + item.value))}
                    </li>
                ))}
            </ul>
        );
    };

    return (
        <>
            <div className="treeVewContainer">{renderTree(treeViewData)}</div>
        </>
    );
};

export default TreeView;


